export default function Home() {
  return (
    <main>
      <h2>Welcome to Siyeb</h2>
      <p>This is a Lovable-ready starter for the compliance platform.</p>
      <ul>
        <li>Next.js App Router</li>
        <li>MongoDB with Mongoose</li>
        <li>JWT Auth + RBAC</li>
      </ul>
    </main>
  )
}
